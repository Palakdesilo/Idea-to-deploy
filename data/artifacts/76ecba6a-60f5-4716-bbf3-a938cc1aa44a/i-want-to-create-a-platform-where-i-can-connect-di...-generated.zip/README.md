# README_TEMPLATE Document for I want to create a platform where I can connect direct to farmer for buy fruits or vegetables.

